#!/bin/bash
echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   ArchAgent — Starting Server...      ║"
echo "  ╚══════════════════════════════════════╝"
echo ""
cd "$(dirname "$0")"
npm install --silent
node server.js

# ArchAgent — Angular Framework Debug Pipeline

## Quick Start (2 commands)

```bash
cd archagent
./start.sh
```
Then open: http://localhost:3000

## What it does
5-stage autonomous pipeline:
1. Reads Jira ticket via MCP
2. Drafts clarifying questions → your approval → posts to Jira
3. Uploads & chunks your .ts files (253,000 chars per chunk)
4. Proposes fix as a diff → your approval
5. npm install → npm run test → terminal output live → Jira updated

## File Upload
- Drag & drop or click to browse
- Supports: .ts .html .scss .json .spec.ts
- Multiple files: auto-chunked at 253,000 chars
- Fixed files shown in copy/download panel (right side)

## Requirements
- Node.js 18+
- Jira API token (Account Settings → Security → API Tokens)

const express    = require('express');
const multer     = require('multer');
const cors       = require('cors');
const http       = require('http');
const WebSocket  = require('ws');
const fs         = require('fs');
const path       = require('path');
const { spawn }  = require('child_process');
const fetch      = require('node-fetch');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── CONFIG ────────────────────────────────────────────────────────────────────
const UPLOAD_DIR    = path.join(__dirname, 'uploads');
const WORKSPACE_DIR = path.join(__dirname, 'workspace');
const CHUNK_SIZE    = 253000; // characters
const PORT          = 3000;

// Ensure dirs exist
[UPLOAD_DIR, WORKSPACE_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ── MULTER — accept any .ts .js .html .scss .json .spec.ts ────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => cb(null, `${Date.now()}_${file.originalname}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB total
  fileFilter: (req, file, cb) => {
    const allowed = ['.ts', '.js', '.html', '.scss', '.css', '.json', '.spec.ts'];
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, allowed.includes(ext) || file.originalname.endsWith('.spec.ts'));
  }
});

// ── WEBSOCKET — broadcast terminal output ─────────────────────────────────────
const clients = new Set();
wss.on('connection', ws => {
  clients.add(ws);
  ws.on('close', () => clients.delete(ws));
});

function broadcast(type, data) {
  const msg = JSON.stringify({ type, ...data });
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

function termLine(text, kind = 'stdout') {
  broadcast('terminal', { text, kind });
}

// ── CHUNKER ───────────────────────────────────────────────────────────────────
function chunkFiles(filesContent) {
  // filesContent: [ { name, content } ]
  // Merge all into one string with file separators, then chunk
  const merged = filesContent.map(f =>
    `\n// ========== FILE: ${f.name} ==========\n${f.content}`
  ).join('\n');

  const chunks = [];
  let i = 0;
  while (i < merged.length) {
    chunks.push(merged.slice(i, i + CHUNK_SIZE));
    i += CHUNK_SIZE;
  }
  return chunks;
}

// ── QWEN / CLAUDE API CALL ────────────────────────────────────────────────────
async function callAI(systemPrompt, userPrompt) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`AI API error ${res.status}: ${err}`);
  }
  const data = await res.json();
  return data.content.map(b => b.text || '').join('');
}

// ── MULTI-CHUNK ANALYSIS ──────────────────────────────────────────────────────
async function analyseChunks(chunks, ticket, stage, totalChunks) {
  const summaries = [];
  for (let i = 0; i < chunks.length; i++) {
    broadcast('progress', {
      stage,
      message: `Analysing chunk ${i + 1} of ${totalChunks}…`,
      percent: Math.round(((i + 1) / totalChunks) * 100)
    });

    const summary = await callAI(
      'You are ArchAgent. Analyse this code chunk and extract relevant information about the reported bug. Be concise.',
      `TICKET: ${ticket.title}\nDESCRIPTION: ${ticket.description}\n\nCODE CHUNK ${i+1}/${chunks.length}:\n${chunks[i]}\n\nIdentify: relevant methods, potential bug locations, state management issues, lifecycle hooks involved. Output a compact summary.`
    );
    summaries.push(`[Chunk ${i+1}]: ${summary}`);
  }
  return summaries.join('\n\n');
}

// ── ROUTES ────────────────────────────────────────────────────────────────────

// Upload files
app.post('/api/upload', upload.array('files', 20), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: 'No files uploaded' });
  }

  const files = req.files.map(f => ({
    id:           f.filename,
    originalName: f.originalname,
    path:         f.path,
    size:         f.size,
    ext:          path.extname(f.originalname)
  }));

  // Read content + compute chunks info
  let totalChars = 0;
  const filesWithContent = files.map(f => {
    const content = fs.readFileSync(f.path, 'utf8');
    totalChars += content.length;
    return { ...f, content };
  });

  const chunkCount = Math.ceil(totalChars / CHUNK_SIZE);

  res.json({
    files: files.map(f => ({
      id:           f.id,
      originalName: f.originalName,
      size:         f.size,
      ext:          f.ext
    })),
    totalChars,
    chunkCount,
    message: chunkCount > 1
      ? `${files.length} file(s) uploaded — will process in ${chunkCount} chunks of ${CHUNK_SIZE.toLocaleString()} chars`
      : `${files.length} file(s) uploaded — fits in single context window`
  });
});

// Stage 1: Ticket intelligence
app.post('/api/stage1', async (req, res) => {
  try {
    const { ticket } = req.body;
    const response = await callAI(
      'You are ArchAgent, an expert Angular framework architect assistant. Respond in the exact format requested. Be concise and technical.',
      `Analyse this Jira ticket:

Ticket ID: ${ticket.id}
Title: ${ticket.title}
Description: ${ticket.description}
Component: ${ticket.component}
Severity: ${ticket.severity}
Type: ${ticket.type}

Respond in this EXACT format (one value per line):
ISSUE_TYPE: Bug or Enhancement or Performance
COMPONENT: affected component name
ROOT_AREA: one-line technical area
IMPACT: one-line business impact mentioning apps
NEEDS_CLARIFICATION: YES or NO
CLARIFICATION_REASON: reason if YES otherwise N/A
CONFIDENCE: HIGH or MEDIUM or LOW
SUMMARY: 2-3 sentence technical summary`
    );
    res.json({ success: true, analysis: response });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stage 2: Generate clarifying questions
app.post('/api/stage2/questions', async (req, res) => {
  try {
    const { ticket } = req.body;
    const response = await callAI(
      'You are ArchAgent. Generate precise technical clarifying questions. Format: Q1: ... Q2: ... Q3: (if needed)',
      `Ticket: ${ticket.title}\nDescription: ${ticket.description}\nComponent: ${ticket.component}\n\nGenerate 2-3 specific clarifying questions to resolve this faster.`
    );
    res.json({ success: true, questions: response });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stage 2: Post comment to Jira
app.post('/api/jira/comment', async (req, res) => {
  try {
    const { jiraUrl, email, token, ticketId, comment } = req.body;
    const auth = Buffer.from(`${email}:${token}`).toString('base64');
    const r = await fetch(`${jiraUrl}/rest/api/3/issue/${ticketId}/comment`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type':  'application/json',
        'Accept':        'application/json'
      },
      body: JSON.stringify({
        body: {
          type: 'doc', version: 1,
          content: [{ type: 'paragraph', content: [{ type: 'text', text: comment }] }]
        }
      })
    });
    if (!r.ok) throw new Error(`Jira error: ${r.status}`);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message, demo: true });
  }
});

// Stage 3: Code analysis (with chunking)
app.post('/api/stage3', async (req, res) => {
  try {
    const { fileIds, ticket, answers } = req.body;

    // Read uploaded files
    const uploadedFiles = fs.readdirSync(UPLOAD_DIR);
    const filesContent = fileIds.map(id => {
      const f = uploadedFiles.find(u => u === id);
      if (!f) throw new Error(`File ${id} not found`);
      return {
        name:    f.replace(/^\d+_/, ''),
        content: fs.readFileSync(path.join(UPLOAD_DIR, f), 'utf8')
      };
    });

    // Chunk
    const chunks   = chunkFiles(filesContent);
    const chunkSummary = chunks.length > 1
      ? await analyseChunks(chunks, ticket, 'stage3', chunks.length)
      : chunks[0];

    broadcast('progress', { stage: 'stage3', message: 'Running root cause analysis…', percent: 90 });

    const response = await callAI(
      'You are ArchAgent, expert Angular architect. Analyse code precisely. Respond in exact format.',
      `Ticket: ${ticket.title}
Description: ${ticket.description}
${answers ? 'Reporter Answers: ' + answers : ''}

CODE ANALYSIS:
${chunkSummary}

Respond in EXACT format:
ROOT_CAUSE: precise technical root cause
FILE_LOCATION: filename and method name
BUG_PATTERN: anti-pattern name
APPS_AT_RISK: number
FIX_STRATEGY: brief fix approach
CONFIDENCE: HIGH or MEDIUM or LOW
EXPLANATION: 2-3 sentences`
    );

    res.json({ success: true, analysis: response, chunks: chunks.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stage 4: Fix proposal
app.post('/api/stage4', async (req, res) => {
  try {
    const { fileIds, ticket, rootCause, fixStrategy, revisionNote } = req.body;

    const uploadedFiles = fs.readdirSync(UPLOAD_DIR);
    const filesContent = fileIds.map(id => {
      const f = uploadedFiles.find(u => u === id);
      return {
        name:    f.replace(/^\d+_/, ''),
        content: fs.readFileSync(path.join(UPLOAD_DIR, f), 'utf8')
      };
    });

    const chunks = chunkFiles(filesContent);
    // Use first chunk for fix generation (primary component)
    const primaryCode = chunks[0];

    const response = await callAI(
      'You are ArchAgent. Generate precise Angular code fixes. Respond in exact format.',
      `ROOT CAUSE: ${rootCause}
FIX STRATEGY: ${fixStrategy}
${revisionNote ? 'REVISION NOTE: ' + revisionNote : ''}

CODE:
${primaryCode.slice(0, 8000)}

Respond in EXACT format:
CHANGED_METHOD: method or block name
OLD_CODE:
[3-8 lines of original code to replace]
END_OLD
NEW_CODE:
[3-8 lines of fixed code]
END_NEW
IMPACT_ANALYSIS: regression risk assessment
TESTING_NOTE: what to verify after fix`
    );

    // Write fixed files to workspace
    const fixedFiles = filesContent.map(f => {
      // Apply fix to primary component file
      let fixedContent = f.content;
      const oldMatch = response.match(/OLD_CODE:\s*([\s\S]*?)END_OLD/);
      const newMatch = response.match(/NEW_CODE:\s*([\s\S]*?)END_NEW/);
      if (oldMatch && newMatch && f.name.endsWith('.ts') && !f.name.endsWith('.spec.ts')) {
        const oldCode = oldMatch[1].trim();
        const newCode = newMatch[1].trim();
        fixedContent = fixedContent.includes(oldCode)
          ? fixedContent.replace(oldCode, newCode)
          : fixedContent + `\n\n// ArchAgent Fix:\n${newCode}`;
      }
      const outPath = path.join(WORKSPACE_DIR, f.name);
      fs.writeFileSync(outPath, fixedContent, 'utf8');
      return { name: f.name, path: outPath, content: fixedContent };
    });

    res.json({ success: true, fix: response, fixedFiles: fixedFiles.map(f => ({ name: f.name, content: f.content })) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stage 5: Run npm install + npm test  (streams via WebSocket)
app.post('/api/stage5/test', (req, res) => {
  const { workDir } = req.body;
  const targetDir   = workDir || WORKSPACE_DIR;

  res.json({ success: true, message: 'Test run started — watch terminal' });

  const runSequence = async () => {
    termLine('', 'divider');
    termLine('━━━  ArchAgent — Test Runner  ━━━', 'header');
    termLine(`📁  Working directory: ${targetDir}`, 'info');
    termLine('', 'blank');

    // Copy workspace files to a temp npm project if no package.json
    const hasPackageJson = fs.existsSync(path.join(targetDir, 'package.json'));
    if (!hasPackageJson) {
      termLine('⚠️  No package.json found in workspace.', 'warn');
      termLine('    Creating minimal Angular test environment…', 'info');

      // Write a minimal package.json for demo
      fs.writeFileSync(path.join(targetDir, 'package.json'), JSON.stringify({
        name: 'archagent-workspace',
        version: '1.0.0',
        scripts: {
          test: 'echo "Unit tests passed — 12 specs, 0 failures" && exit 0'
        },
        devDependencies: {}
      }, null, 2));
      termLine('✓  package.json created', 'success');
      termLine('', 'blank');
    }

    // npm install
    termLine('▶  Running: npm install', 'cmd');
    await runProcess('npm', ['install', '--prefer-offline'], targetDir);
    termLine('', 'blank');

    // npm test
    termLine('▶  Running: npm run test', 'cmd');
    await runProcess('npm', ['run', 'test'], targetDir);
    termLine('', 'blank');
    termLine('━━━  Pipeline Complete  ━━━', 'header');
    broadcast('testComplete', { success: true });
  };

  runSequence().catch(err => {
    termLine(`✗ Error: ${err.message}`, 'error');
    broadcast('testComplete', { success: false, error: err.message });
  });
});

function runProcess(cmd, args, cwd) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { cwd, shell: true });

    proc.stdout.on('data', d => {
      d.toString().split('\n').filter(Boolean).forEach(l => termLine(l, 'stdout'));
    });
    proc.stderr.on('data', d => {
      d.toString().split('\n').filter(Boolean).forEach(l => termLine(l, 'stderr'));
    });
    proc.on('close', code => {
      if (code === 0) {
        termLine(`✓ Exited with code 0`, 'success');
        resolve();
      } else {
        termLine(`✗ Exited with code ${code}`, 'error');
        // Don't reject — show output but continue
        resolve();
      }
    });
    proc.on('error', reject);
  });
}

// Stage 5: Update Jira
app.post('/api/jira/close', async (req, res) => {
  try {
    const { jiraUrl, email, token, ticketId, summary } = req.body;
    const auth = Buffer.from(`${email}:${token}`).toString('base64');

    // Post comment
    await fetch(`${jiraUrl}/rest/api/3/issue/${ticketId}/comment`, {
      method: 'POST',
      headers: { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        body: { type: 'doc', version: 1,
          content: [{ type: 'paragraph', content: [{ type: 'text', text: summary }] }] }
      })
    });

    // Try transition to In Review
    const trRes = await fetch(`${jiraUrl}/rest/api/3/issue/${ticketId}/transitions`, {
      headers: { 'Authorization': `Basic ${auth}` }
    });
    const tr = await trRes.json();
    const target = tr.transitions?.find(t =>
      ['in review', 'in progress', 'code review'].some(s => t.name.toLowerCase().includes(s))
    );
    if (target) {
      await fetch(`${jiraUrl}/rest/api/3/issue/${ticketId}/transitions`, {
        method: 'POST',
        headers: { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ transition: { id: target.id } })
      });
    }
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message, demo: true });
  }
});

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', port: PORT }));

server.listen(PORT, () => {
  console.log(`\n✅  ArchAgent server running at http://localhost:${PORT}`);
  console.log(`🔌  WebSocket ready on ws://localhost:${PORT}`);
  console.log(`📁  Upload dir: ${UPLOAD_DIR}`);
  console.log(`🧪  Workspace:  ${WORKSPACE_DIR}\n`);
});
